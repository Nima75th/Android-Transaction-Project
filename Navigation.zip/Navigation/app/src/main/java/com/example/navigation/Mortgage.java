package com.example.navigation;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Mortgage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mortgage);
    }
}